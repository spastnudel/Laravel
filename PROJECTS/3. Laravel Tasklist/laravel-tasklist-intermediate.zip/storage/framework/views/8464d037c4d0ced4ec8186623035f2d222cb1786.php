<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Tasks</div>

                    <div class="panel-body">
                        <?php /* <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> */ ?>

                        <form action="<?php echo e(route('tasks.store')); ?>" method="post" class="form-horizontal">
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-sm-3 control-label">Task</label>

                                <div class="col-sm-6">
                                    <input type="text" name="name" id="name" class="form-control">
                                    
                                    <?php if($errors->has('name')): ?>
                                        <div class="help-block">
                                            Name is required
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-sm-offset-3 col-sm-6">
                                    <button type="submit" class="btn btn-default">Add task</button>
                                </div>
                            </div>
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Current tasks</div>

                    <div class="panel-body">
                        <?php if($tasks->count()): ?>
                            <table class="table table-striped">
                                <thead>
                                    <th>Task</th>
                                    <th>&nbsp;</th>
                                </thead>
                                <tbody>
                                    <?php foreach($tasks as $task): ?>
                                        <tr>
                                            <td><?php echo e($task->name); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="post">
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <?php echo e(csrf_field()); ?>

                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p>You have no tasks!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>