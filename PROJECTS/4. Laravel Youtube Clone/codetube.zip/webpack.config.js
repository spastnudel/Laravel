{
    module: {
        noParse: [
            /node_modules[\\/]video\.js/
        ]
    }
}
