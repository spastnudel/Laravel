<?php

return [

    'buckets' => [
        'videos' => 'https://s3.amazonaws.com/videos.codetube.com',
        'images' => 'https://s3.amazonaws.com/images.codetube.com',
    ]

];
