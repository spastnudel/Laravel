<?php $__env->startSection('main'); ?>
    <div class="content">
        <?php echo $__env->make('posts/partials/list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="sidebar">
        <?php echo $__env->make('templates/partials/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>