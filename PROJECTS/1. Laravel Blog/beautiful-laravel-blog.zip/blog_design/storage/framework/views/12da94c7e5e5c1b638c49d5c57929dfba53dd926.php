<div class="image-header">
    <img src="<?php echo e($url); ?>" alt="<?php echo e(isset($altText) ? $altText : ''); ?>" class="image-header__image">
</div>
