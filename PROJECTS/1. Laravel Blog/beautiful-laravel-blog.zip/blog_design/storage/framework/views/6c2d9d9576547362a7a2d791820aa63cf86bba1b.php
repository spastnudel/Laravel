<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="post">
            <div class="post__header"><a href="">Should you learn to code?</a></div>
            <div class="post__preview">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, autem.</div>
        </div>
        <div class="post">
            <div class="post__header"><a href="">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta, vel.</a></div>
            <div class="post__preview">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, autem.</div>
        </div>
    </div>
    <div class="sidebar">
        <h3>Tags</h3>
        
        <a href="#" class="tag">Coding</a>
        <a href="#" class="tag">Education</a>
        <a href="#" class="tag">Work</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>