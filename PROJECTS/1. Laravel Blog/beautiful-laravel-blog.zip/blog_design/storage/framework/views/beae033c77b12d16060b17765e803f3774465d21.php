<h3>Tags</h3>        
<a href="#" class="tag">Coding</a>
<a href="#" class="tag">Education</a>
<a href="#" class="tag">Work</a>