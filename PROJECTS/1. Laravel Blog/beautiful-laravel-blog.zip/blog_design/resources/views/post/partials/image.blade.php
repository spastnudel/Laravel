<div class="image-header">
    <img src="{{ $url }}" alt="{{ $altText or '' }}" class="image-header__image">
</div>
