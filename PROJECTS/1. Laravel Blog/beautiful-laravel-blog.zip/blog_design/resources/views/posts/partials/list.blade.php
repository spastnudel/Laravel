<div class="post">
    <div class="post__header"><a href="">Should you learn to code?</a></div>
    <div class="post__author">By <a href="#">Alex Garrett</a> <span class="post__time">5 days ago</span></div>
    <div class="post__preview">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, autem.</div>
</div>
<div class="post">
    <div class="post__header"><a href="">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta, vel.</a></div>
    <div class="post__author">By <a href="#">Alex Garrett</a> <span class="post__time">3 days ago</span></div>
    <div class="post__preview">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, autem.</div>
</div>
