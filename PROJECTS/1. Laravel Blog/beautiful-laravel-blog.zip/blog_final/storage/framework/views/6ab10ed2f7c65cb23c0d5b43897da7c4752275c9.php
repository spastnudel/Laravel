<?php if($tags->count()): ?>
    <h3>Tags</h3>
    
    <?php foreach($tags as $tag): ?>
        <a href="<?php echo e(route('posts.tagged', $tag->slug)); ?>" class="tag"><?php echo e($tag->name); ?></a>
    <?php endforeach; ?>
<?php endif; ?>
