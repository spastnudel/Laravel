<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('post/partials/image', [
        'url' => $post->image
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <article class="article">
        <div class="author">
            <img src="<?php echo e($post->author->avatar()); ?>" alt="<?php echo e($post->author->fullName()); ?>" class="author__image">
            <div class="author__details">
                <a href="" class="author__name"><?php echo e($post->author->fullName()); ?></a>
                <div class="author__post-time"><?php echo e($post->created_at->diffForHumans()); ?></div>
            </div>
        </div>

        <h1 class="article__header"><?php echo e($post->title); ?></h1>
        <h2 class="article__subheader"><?php echo e($post->teaser); ?></h2>
        <div class="article__body">
            <?php echo Markdown::convertToHtml(e($post->body)); ?>

        </div>

        <?php foreach($post->tags as $tag): ?>
            <a href="<?php echo e(route('posts.tagged', $tag->slug)); ?>" class="tag"><?php echo e($tag->name); ?></a>
        <?php endforeach; ?>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>