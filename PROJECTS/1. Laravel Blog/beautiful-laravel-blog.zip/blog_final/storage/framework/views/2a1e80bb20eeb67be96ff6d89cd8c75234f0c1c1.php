<?php if($posts->count()): ?>
    <?php foreach($posts as $post): ?>
        <div class="post">
            <div class="post__header"><a href="<?php echo e(route('post.show', $post->slug)); ?>"><?php echo e($post->title); ?></a></div>
            <div class="post__author">By <a href="#"><?php echo e($post->author->fullName()); ?></a> <span class="post__time"><?php echo e($post->created_at->diffForHumans()); ?></span></div>
            <div class="post__preview"><?php echo e($post->teaser); ?></div>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>No posts to see here</p>
<?php endif; ?>
