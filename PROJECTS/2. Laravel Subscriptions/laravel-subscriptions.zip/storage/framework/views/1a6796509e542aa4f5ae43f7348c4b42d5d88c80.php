<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading"><?php echo e($plan->name); ?></div>

                    <div class="panel-body">
                        <form action="<?php echo e(route('subscription.create')); ?>" method="post">
                            <div id="dropin-container"></div>
                            <hr>
                            <button type="submit" class="btn btn-default hidden" id="payment-button">Pay</button>
                            <input type="hidden" name="plan" value="<?php echo e($plan->id); ?>">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://js.braintreegateway.com/js/braintree-2.26.0.min.js"></script>

    <script>
        $.ajax({
            url: '<?php echo e(route('braintree.token')); ?>'
        }).success(function (response) {
            braintree.setup(response.data.token, 'dropin', {
                container: 'dropin-container',
                onReady: function () {
                    $('#payment-button').removeClass('hidden');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>