<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Subscription</div>

                    <div class="panel-body">
                        <?php if(Auth::user()->subscription('main')->cancelled()): ?>
                            <p>You have cancelled your subscription. You still have access until <?php echo e(Auth::user()->subscription('main')->ends_at->format('dS M Y')); ?></p>
                            <form action="<?php echo e(route('subscription.resume')); ?>" method="post">
                                <button type="submit" class="btn btn-default">Resume subscription</button>
                                <?php echo e(csrf_field()); ?>

                            </form>
                        <?php else: ?>
                            <p>You are currently subscribed!</p>
                            <form action="<?php echo e(route('subscription.cancel')); ?>" method="post">
                                <button type="submit" class="btn btn-default">Cancel subscription</button>
                                <?php echo e(csrf_field()); ?>

                            </form>
                        <?php endif; ?>
                        <hr>
                        <a href="<?php echo e(route('plans.index')); ?>">Change plan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>