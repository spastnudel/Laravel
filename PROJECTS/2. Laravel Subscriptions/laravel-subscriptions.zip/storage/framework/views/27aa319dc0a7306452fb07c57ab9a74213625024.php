<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Plans</div>

                    <div class="panel-body">
                        <ul class="list-group">
                            <?php foreach($plans as $plan): ?>
                                <li class="list-group-item clearfix">
                                    <div class="pull-left">
                                        <h4><?php echo e($plan->name); ?></h4>
                                        <h4>£<?php echo e(number_format($plan->cost, 2)); ?> monthly</h4>
                                        <?php if($plan->description): ?>
                                            <p><?php echo e($plan->description); ?></p>
                                        <?php endif; ?>
                                    </div>

                                    <?php if(!Auth::user()->subscribedToPlan($plan->braintree_plan, 'main')): ?>
                                        <a href="<?php echo e(route('plans.show', $plan->slug)); ?>" class="btn btn-default pull-right">Choose</a>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>