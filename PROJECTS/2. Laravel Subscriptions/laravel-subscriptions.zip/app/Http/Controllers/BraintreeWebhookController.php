<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Laravel\Cashier\Http\Controllers\WebhookController;

class BraintreeWebhookController extends WebhookController
{
    //
}
